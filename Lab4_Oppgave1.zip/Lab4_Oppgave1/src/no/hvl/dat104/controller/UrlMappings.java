package no.hvl.dat104.controller;

public class UrlMappings {
    public static final String SHOPPING_LIST_URL = "handleliste";
    public static final String LOGIN_URL = "logginn";
    public static final String LOGOUT_URL = "loggut";
    public static final String REGISTER_URL = "register";
    public static final String LANDING_URL = "kjhjhj";
}
