package no.hvl.dat104.dataaccess.jpa;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ShoppingListEAOTest {
    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void addShoppingList() {
    }

    @Test
    void findShoppingList() {
    }

    @Test
    void updateShoppingList() {
    }

    @Test
    void removeShoppingList() {
    }

    @Test
    void allShoppingListEntity() {
    }

}